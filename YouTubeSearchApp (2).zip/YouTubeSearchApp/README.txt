YouTubeSearchApp - Android Studio project
----------------------------------------
How to open:
1) Download the ZIP and unzip.
2) Open the folder in Android Studio.
3) Let Gradle sync (internet required).
4) Run on an emulator or device.

Notes:
- The project uses the provided API key inside MainActivity (for testing).
- If you get a 403 error, the API key may be restricted or quota exhausted.
- You can change the API key in MainActivity.java
