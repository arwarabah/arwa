package com.example.youtube_search.models;

public class Thumbnail {
    public String url;
    public int width;
    public int height;
}
