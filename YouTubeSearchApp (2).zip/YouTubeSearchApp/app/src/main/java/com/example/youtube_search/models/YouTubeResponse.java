package com.example.youtube_search.models;

import java.util.List;

public class YouTubeResponse {
    public String kind;
    public String etag;
    public PageInfo pageInfo;
    public List<Item> items;

    public static class PageInfo {
        public int totalResults;
        public int resultsPerPage;
    }
}
