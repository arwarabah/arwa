package com.example.youtube_search.models;

import com.google.gson.annotations.SerializedName;

public class Thumbnails {
    @SerializedName("default")
    public Thumbnail defaultThumbnail;
    public Thumbnail medium;
    public Thumbnail high;
}
