package com.example.youtube_search.models;

public class Item {
    public Id id;
    public Snippet snippet;
}
