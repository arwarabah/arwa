package com.example.youtube_search.network;

import com.example.youtube_search.models.YouTubeResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface YouTubeApiService {
    @GET("search")
    Call<YouTubeResponse> searchVideos(
            @Query("part") String part,
            @Query("type") String type,
            @Query("q") String q,
            @Query("maxResults") int maxResults,
            @Query("key") String apiKey
    );
}
