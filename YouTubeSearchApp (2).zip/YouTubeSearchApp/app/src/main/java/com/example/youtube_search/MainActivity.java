package com.example.youtube_search;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.youtube_search.adapters.VideoAdapter;
import com.example.youtube_search.models.Item;
import com.example.youtube_search.models.YouTubeResponse;
import com.example.youtube_search.network.YouTubeApiService;

import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final String API_KEY = "AIzaSyAEk7F_bbhTFUWxwJXDn5fzxviwCJYk7EY";
    private static final String BASE_URL = "https://www.googleapis.com/youtube/v3/";

    private EditText etQuery;
    private Button btnSearch;
    private ProgressBar progress;
    private RecyclerView rvResults;
    private TextView tvMessage;
    private VideoAdapter adapter;
    private YouTubeApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etQuery = findViewById(R.id.etQuery);
        btnSearch = findViewById(R.id.btnSearch);
        progress = findViewById(R.id.progress);
        rvResults = findViewById(R.id.rvResults);
        tvMessage = findViewById(R.id.tvMessage);

        adapter = new VideoAdapter(this);
        rvResults.setLayoutManager(new LinearLayoutManager(this));
        rvResults.setAdapter(adapter);

        // Retrofit setup with logging
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(logging)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        apiService = retrofit.create(YouTubeApiService.class);

        btnSearch.setOnClickListener(v -> startSearch());

        // handle keyboard search button
        etQuery.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                startSearch();
                return true;
            }
            return false;
        });
    }

    private void startSearch() {
        String q = etQuery.getText().toString().trim();
        if (TextUtils.isEmpty(q)) {
            Toast.makeText(this, "فضلاً ادخل كلمة بحث.", Toast.LENGTH_SHORT).show();
            return;
        }

        tvMessage.setVisibility(TextView.GONE);
        progress.setVisibility(ProgressBar.VISIBLE);

        Call<YouTubeResponse> call = apiService.searchVideos(
                "snippet",
                "video",
                q,
                15,
                API_KEY
        );

        call.enqueue(new Callback<YouTubeResponse>() {
            @Override
            public void onResponse(Call<YouTubeResponse> call, Response<YouTubeResponse> response) {
                progress.setVisibility(ProgressBar.GONE);

                if (!response.isSuccessful()) {
                    String err = "خطأ في الاتصال: رمز الاستجابة " + response.code();
                    if (response.code() == 403) err = "مفتاح API غير صالح أو تجاوزت الحصة (403).";
                    tvMessage.setText(err);
                    tvMessage.setVisibility(TextView.VISIBLE);
                    adapter.setItems(null);
                    return;
                }

                YouTubeResponse body = response.body();
                if (body == null || body.items == null || body.items.isEmpty()) {
                    tvMessage.setText("لا توجد نتائج.");
                    tvMessage.setVisibility(TextView.VISIBLE);
                    adapter.setItems(null);
                    return;
                }

                List<Item> items = body.items;
                adapter.setItems(items);
            }

            @Override
            public void onFailure(Call<YouTubeResponse> call, Throwable t) {
                progress.setVisibility(ProgressBar.GONE);
                tvMessage.setText("فشل في الاتصال: " + t.getMessage());
                tvMessage.setVisibility(TextView.VISIBLE);
                adapter.setItems(null);
            }
        });
    }
}
