package com.example.youtube_search.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.youtube_search.R;
import com.example.youtube_search.models.Item;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VH> {

    private final Context context;
    private final List<Item> items = new ArrayList<>();

    public VideoAdapter(Context context) {
        this.context = context;
    }

    public void setItems(List<Item> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_video, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Item it = items.get(position);
        holder.tvTitle.setText(it.snippet.title);
        holder.tvChannel.setText(it.snippet.channelTitle);
        holder.tvPublish.setText(it.snippet.publishedAt);
        holder.tvDesc.setText(it.snippet.description);

        String thumb = null;
        if (it.snippet.thumbnails != null) {
            if (it.snippet.thumbnails.high != null) thumb = it.snippet.thumbnails.high.url;
            else if (it.snippet.thumbnails.medium != null) thumb = it.snippet.thumbnails.medium.url;
        }

        Glide.with(context)
                .load(thumb)
                .centerCrop()
                .into(holder.ivThumb);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView ivThumb;
        TextView tvTitle, tvChannel, tvPublish, tvDesc;

        VH(@NonNull View itemView) {
            super(itemView);
            ivThumb = itemView.findViewById(R.id.ivThumb);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvChannel = itemView.findViewById(R.id.tvChannel);
            tvPublish = itemView.findViewById(R.id.tvPublish);
            tvDesc = itemView.findViewById(R.id.tvDesc);
        }
    }
}
