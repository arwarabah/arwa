package com.example.youtube_search.models;

public class Id {
    public String kind;
    public String videoId;
}
