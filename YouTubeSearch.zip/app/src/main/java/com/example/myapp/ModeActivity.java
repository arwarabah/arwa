package com.example.myapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class ModeActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TextView tvCurrentTab;
    private ViewPagerAdapter viewPagerAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode);

        // تفعيل زر الرجوع للأعلى (Up Button)
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Mode Selection");
        }

        viewPager = findViewById(R.id.viewPager);
        tvCurrentTab = findViewById(R.id.tvCurrentTab);
        Button btnSetMode = findViewById(R.id.btnSetMode);
        TabLayout tabLayout = findViewById(R.id.tabLayout);

        setupViewPagerAndTabs(tabLayout);

        btnSetMode.setOnClickListener(this::showPopupMenu);
    }

    private void setupViewPagerAndTabs(TabLayout tabLayout) {
        viewPagerAdapter = new ViewPagerAdapter(this);
        viewPager.setAdapter(viewPagerAdapter);

        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> {
                    switch (position) {
                        case 0:
                            tab.setText("First");
                            break;
                        case 1:
                            tab.setText("Second");
                            break;
                        default:
                            tab.setText("Third");
                            break;
                    }
                }).attach();

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                String tabName;
                switch (position) {
                    case 0:
                        tabName = "First";
                        break;
                    case 1:
                        tabName = "Second";
                        break;
                    default:
                        tabName = "Third";
                        break;
                }
                tvCurrentTab.setText("Current: " + tabName);
            }
        });
    }

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.action_light) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                Toast.makeText(this, "Light Mode", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.action_night) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                Toast.makeText(this, "Night Mode", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.action_system) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                Toast.makeText(this, "System Default", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });
        popupMenu.show();
    }

    // التعامل مع زر الرجوع (Back Button)
    @SuppressLint("GestureBackNavigation")
    @Override
    public void onBackPressed() {
        int currentItem = viewPager.getCurrentItem();
        if (currentItem == 0) {
            // إذا كان في First Tab -> ارجع إلى MainActivity
            super.onBackPressed();
        } else {
            // إذا كان في Second أو Third -> انتقل إلى First Tab
            viewPager.setCurrentItem(0);
            Toast.makeText(this, "Returned to First Tab", Toast.LENGTH_SHORT).show();
        }
    }

    // التعامل مع زر الرجوع للأعلى (Up Button)
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private class ViewPagerAdapter extends RecyclerView.Adapter {
        public ViewPagerAdapter(ModeActivity modeActivity) {
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return null;
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        }

        @Override
        public int getItemCount() {
            return 0;
        }
    }
}