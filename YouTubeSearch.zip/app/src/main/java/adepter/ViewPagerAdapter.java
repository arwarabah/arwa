package adepter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import com.example.myapp.f.first_freg;
import com.example.myapp.f.second_freg;
import com.example.myapp.f.third_freg;

public class ViewPagerAdapter extends FragmentStateAdapter {

    public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new first_freg();
            case 1:
                return new second_freg();
            default:
                return new third_freg ();
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}